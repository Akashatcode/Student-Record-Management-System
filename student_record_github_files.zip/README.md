# Student Record Management System

A beginner-friendly Data Structures mini project written in C using a **singly linked list**.

## Features
- Add student records
- Display all student records
- Search by register number
- Update student details
- Delete a student record
- Sort records by marks

## Student data
Each record contains:
- Register number
- Name
- Marks

## Requirements
A C compiler such as GCC, Code::Blocks, or another standard C compiler.

## How to compile and run

Using GCC:

```bash
gcc student_management.c -o student_management
./student_management
```

On Windows, run the generated program with:

```bash
student_management.exe
```

## Note
This is an educational console application. Records are stored in memory only and are not saved after the program exits. The current version accepts one-word student names.
