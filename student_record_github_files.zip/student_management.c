#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NAME_LEN 50

typedef struct Student {
    int regNo;
    char name[NAME_LEN];
    float marks;
    struct Student *next;
} Student;

Student *head = NULL;

Student *findStudent(int regNo) {
    Student *cur = head;
    while (cur != NULL) {
        if (cur->regNo == regNo) return cur;
        cur = cur->next;
    }
    return NULL;
}

void addStudent(void) {
    int regNo;
    Student *node, *tail;

    printf("Register number: ");
    if (scanf("%d", &regNo) != 1) return;
    if (findStudent(regNo) != NULL) {
        printf("Register number already exists.\n");
        return;
    }

    node = malloc(sizeof(Student));
    if (node == NULL) {
        printf("Memory allocation failed.\n");
        return;
    }

    node->regNo = regNo;
    printf("Name (one word): ");
    scanf("%49s", node->name);
    printf("Marks (0-100): ");
    if (scanf("%f", &node->marks) != 1 ||
        node->marks < 0 || node->marks > 100) {
        free(node);
        printf("Invalid marks.\n");
        return;
    }

    node->next = NULL;
    if (head == NULL) {
        head = node;
    } else {
        tail = head;
        while (tail->next != NULL) tail = tail->next;
        tail->next = node;
    }
    printf("Student added successfully.\n");
}

void displayStudents(void) {
    Student *cur = head;
    if (cur == NULL) {
        printf("No records found.\n");
        return;
    }
    printf("\nReg No       Name                 Marks\n");
    while (cur != NULL) {
        printf("%-12d %-20s %.2f\n",
               cur->regNo, cur->name, cur->marks);
        cur = cur->next;
    }
}

void searchStudent(void) {
    int regNo;
    Student *s;
    printf("Register number to search: ");
    if (scanf("%d", &regNo) != 1) return;
    s = findStudent(regNo);
    if (s == NULL) printf("Student not found.\n");
    else printf("%d | %s | %.2f marks\n",
                s->regNo, s->name, s->marks);
}

void updateStudent(void) {
    int regNo;
    float marks;
    Student *s;
    printf("Register number to update: ");
    if (scanf("%d", &regNo) != 1) return;
    s = findStudent(regNo);
    if (s == NULL) {
        printf("Student not found.\n");
        return;
    }
    printf("New name (one word): ");
    scanf("%49s", s->name);
    printf("New marks (0-100): ");
    if (scanf("%f", &marks) != 1 ||
        marks < 0 || marks > 100) {
        printf("Invalid marks.\n");
        return;
    }
    s->marks = marks;
    printf("Record updated.\n");
}

void deleteStudent(void) {
    int regNo;
    Student *cur = head, *prev = NULL;
    printf("Register number to delete: ");
    if (scanf("%d", &regNo) != 1) return;

    while (cur != NULL && cur->regNo != regNo) {
        prev = cur;
        cur = cur->next;
    }
    if (cur == NULL) {
        printf("Student not found.\n");
        return;
    }
    if (prev == NULL) head = cur->next;
    else prev->next = cur->next;
    free(cur);
    printf("Record deleted.\n");
}

void sortByMarks(void) {
    Student *i, *j;
    if (head == NULL || head->next == NULL) {
        printf("Not enough records to sort.\n");
        return;
    }
    for (i = head; i->next != NULL; i = i->next) {
        for (j = i->next; j != NULL; j = j->next) {
            if (i->marks > j->marks) {
                int r = i->regNo;
                float m = i->marks;
                char n[NAME_LEN];
                strcpy(n, i->name);
                i->regNo = j->regNo;
                i->marks = j->marks;
                strcpy(i->name, j->name);
                j->regNo = r;
                j->marks = m;
                strcpy(j->name, n);
            }
        }
    }
    printf("Sorted by marks in ascending order.\n");
}

void freeAll(void) {
    Student *cur = head;
    while (cur != NULL) {
        Student *next = cur->next;
        free(cur);
        cur = next;
    }
}

int main(void) {
    int choice;
    do {
        printf("\nSTUDENT RECORD MANAGEMENT\n");
        printf("1. Add student\n");
        printf("2. Display students\n");
        printf("3. Search student\n");
        printf("4. Update student\n");
        printf("5. Delete student\n");
        printf("6. Sort by marks\n");
        printf("7. Exit\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input.\n");
            break;
        }
        switch (choice) {
            case 1: addStudent(); break;
            case 2: displayStudents(); break;
            case 3: searchStudent(); break;
            case 4: updateStudent(); break;
            case 5: deleteStudent(); break;
            case 6: sortByMarks(); break;
            case 7: printf("Goodbye.\n"); break;
            default: printf("Choose 1 to 7.\n");
        }
    } while (choice != 7);

    freeAll();
    return 0;
}
